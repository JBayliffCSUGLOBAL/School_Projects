# CSC372_Module_Five_Option_Two
Implementing Recursion to Provide a Product

Using recursion, create a program that will allow a user to enter five numbers. The program will provide the product of all five numbers using recursive methods.

Submit screenshots of your program's execution and output. Include all appropriate source code in a zip file.
