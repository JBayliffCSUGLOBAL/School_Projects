public class CheckingAccount extends BankAccount {
    private double interestRate;
    private static final double OVERDRAFT_FEE = 30.0;

    // Constructor
    public CheckingAccount(String firstName, String lastName, int accountID, double interestRate) {
        super(firstName, lastName, accountID);
        this.interestRate = interestRate;
    }

    // Getters and Setters
    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    // Methods
    public void processWithdrawal(double amount) {
        if (amount > 0) {
            double balance = getBalance();
            if (amount > balance) {
                balance -= (amount + OVERDRAFT_FEE);
                System.out.println("Overdraft! A $30 fee has been accessed.");
            } else {
                balance -= amount;
            }
            // Reflect the updated balance
            // Since balance is private in superclass, consider using reflection or protected methods
            setBalance(balance);
        }
    }

    // Reflects the balance change using reflection or protected methods in superclass
    private void setBalance(double balance) {
        try {
            java.lang.reflect.Field field = BankAccount.class.getDeclaredField("balance");
            field.setAccessible(true);
            field.set(this, balance);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void displayAccount() {
        accountSummary();
        System.out.println("Interest Rate: " + interestRate + "%");
    }
}
