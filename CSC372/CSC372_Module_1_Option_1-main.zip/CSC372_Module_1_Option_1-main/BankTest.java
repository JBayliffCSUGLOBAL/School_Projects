public class BankTest {
    public static void main(String[] args) {
        // Create a BankAccount object
        BankAccount bankAccount = new BankAccount("Peter", "Pumpernickle", 48523);
        bankAccount.deposit(500.00);
        bankAccount.withdrawal(150.00);
        bankAccount.accountSummary();

        System.out.println();

        // Create a CheckingAccount object
        CheckingAccount checkingAccount = new CheckingAccount("Chipper", "Jones", 67890, 1.5);
        checkingAccount.deposit(1000.00);
        checkingAccount.processWithdrawal(1100.00);
        checkingAccount.displayAccount();
    }
}
