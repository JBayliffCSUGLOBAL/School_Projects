#include <iostream>
#include <string>

int main() {
    std::string firstName = "Chipper";
    std::string lastName = "Jones";
    std::string streetAddress = "1520 Coperstown Drive";
    std::string city = "Cooperstown";
    std::string zipCode = "65359";

    std::cout << "First Name: " << firstName << std::endl;
    std::cout << "Last Name: " << lastName << std::endl;
    std::cout << "Street Address: " << streetAddress << std::endl;
    std::cout << "City: " << city << std::endl;
    std::cout << "Zip Code: " << zipCode << std::endl;

    return 0;
}




