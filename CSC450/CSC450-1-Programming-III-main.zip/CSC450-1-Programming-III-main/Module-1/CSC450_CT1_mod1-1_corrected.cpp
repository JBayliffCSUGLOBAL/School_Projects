
/* Simple Program with a few Errors for Correction
   Please be sure to correct all outlined errors.
*/

#include<iostream>

// Standard namespace declaration
using namespace std;

// Main Function
int main()
{
    // Standard Output Statement
    cout << "Welcome to this C++ Program" << endl;

    // Corrected Output Statement
    cout << "I have corrected all errors for this program." << endl;

    // Return statement indicating successful execution
    return 0;
}
