# Module_6_Portfolio_Project
Submit a document with methods for your automobile class, and pseudo code
Submit document with methods for your automobile class, and pseudo code indicating functionality of each method.

Example:

public String RemoveVehicle(String

autoMake, String autoModel, String autoColor, int autoYear)

If

             values entered match values stored in private variables

             remove vehicle information

else

             return message indicating mismatch
