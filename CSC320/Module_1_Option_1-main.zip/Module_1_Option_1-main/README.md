# Module_1_Option_1
 Developing pseudocode
1. Developing pseudocode that prints the following information for a fictional person:
First name
Last name
Street address
City
Zip code
2. Creating a simple java application that will print the items listed above on individual lines.
