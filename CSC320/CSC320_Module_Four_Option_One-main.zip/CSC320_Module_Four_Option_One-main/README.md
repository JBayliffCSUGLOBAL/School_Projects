# CSC320_Module_Four_Option_One
Looping Construct with Floating Point Numbers
Write a program that utilizes a while-loop to read a set of five floating-point values from user input. Include code to prevent an endless loop. Ask the user to enter the values, then print the following data:

Total
Average
Maximum
Minimum
Interest on total at 20%

Compile and submit your pseudocode, source code, and screenshots of the application executing the application, the results and GIT repository in a single document.
