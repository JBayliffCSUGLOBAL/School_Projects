# CSC320_Module_3_Option_1
Option_#1_Calculate Average Withholding
Create a program that will calculate the weekly average tax withholding for a customer given the following weekly income guidelines:

Income less than $500: tax rate 10%
Incomes greater than/equal to $500 and less than $1500: tax rate 15%
Incomes greater than/equal to $1500 and less than $2500: tax rate 20%
Incomes greater than/equal to $2500: tax rate 30%
