# Module_5_Option_2
Get Monthly Temperatures
Develop a Java program that will store data in the form of monthly temperatures for a year. Store the month and temperature in two different arrays. Your program should prompt the user for the month to be viewed and display both the month and average temperature. If "year" is entered, the output for your program should provide the temperature for each month along with the yearly average as well as the highest and lowest monthly averages. Use the looping and decision constructs in combination with the arrays to complete this assignment.

Compile and submit your pseudocode, source code, and screenshots of the application executing the application, the results and GIT repository in a single document.
