import java.util.Iterator;
import java.util.NoSuchElementException;

public class CustomLinkedList {
    private Node head;

    // Node class representing an element in the list
    private class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    // Insert a new node with the given data
    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    // Delete the first occurrence of a node with the given data
    public boolean delete(int data) {
        if (head == null) {
            return false; // List is empty
        }

        // If the head node needs to be removed
        if (head.data == data) {
            head = head.next;
            return true;
        }

        // Search for the node to delete
        Node current = head;
        while (current.next != null && current.next.data != data) {
            current = current.next;
        }

        // If the node was found
        if (current.next != null) {
            current.next = current.next.next;
            return true;
        }

        return false; // Node with given data not found
    }

    // Return an iterator for the linked list
    public Iterator<Integer> iterator() {
        return new LinkedListIterator();
    }

    // Inner class for the iterator
    private class LinkedListIterator implements Iterator<Integer> {
        private Node current = head;

        @Override
        public boolean hasNext() {
            return current != null;
        }

        @Override
        public Integer next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            int data = current.data;
            current = current.next;
            return data;
        }
    }

    public static void main(String[] args) {
        CustomLinkedList linkedList = new CustomLinkedList();

        // Insert some elements
        linkedList.insert(1);
        linkedList.insert(2);
        linkedList.insert(3);

        // Display elements using iterator
        System.out.println("Elements in the linked list:");
        Iterator<Integer> iterator = linkedList.iterator();
        while (iterator.hasNext()) {
            System.out.print(iterator.next() + " ");
        }

        // Delete an element
        System.out.println("\nDeleting element 2...");
        linkedList.delete(2);

        // Display elements after deletion
        System.out.println("Elements in the linked list after deletion:");
        iterator = linkedList.iterator();
        while (iterator.hasNext()) {
            System.out.print(iterator.next() + " ");
        }
    }
}
