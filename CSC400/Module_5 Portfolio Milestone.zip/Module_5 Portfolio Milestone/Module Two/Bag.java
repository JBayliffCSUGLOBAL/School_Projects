import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Bag<T> {
    private List<T> items;

    // Constructor to initialize the bag
    public Bag() {
        this.items = new ArrayList<>();
    }

    // Method to add an element to the bag
    public void add(T item) {
        items.add(item);
    }

    // Method to return the total number of elements in the bag (including duplicates)
    public int size() {
        return items.size();
    }

    // Method to merge another bag into the current bag
    public void merge(Bag<T> otherBag) {
        this.items.addAll(otherBag.items);
    }

    // Method to return a new bag with distinct elements (no duplicates)
    public Bag<T> distinct() {
        Bag<T> distinctBag = new Bag<>();
        Set<T> uniqueItems = new HashSet<>(this.items);
        distinctBag.items.addAll(uniqueItems);
        return distinctBag;
    }

    // Method to display the contents of the bag
    public void printBag() {
        System.out.println(items);
    }
}
