import java.util.Stack;
import java.util.EmptyStackException;

public class PostfixCalculator {

    // This Method evaluates a postfix expression
    public static int evaluatePostfix(String expression) {
        Stack<Integer> stack = new Stack<>();

        for (String token : expression.split(" ")) {
            if (isOperand(token)) { // If token is an operand, push it to the stack
                stack.push(Integer.parseInt(token));
            } else if (isOperator(token)) { // If token is an operator, perform operation
                if (stack.size() < 2) { // Check for invalid expression (not enough operands)
                    throw new IllegalArgumentException("Invalid expression: insufficient operands.");
                }

                int operand2 = stack.pop();
                int operand1 = stack.pop();
                int result = performOperation(token, operand1, operand2);
                stack.push(result); // Push result back to stack
            } else {
                throw new IllegalArgumentException("Invalid expression: unrecognized token '" + token + "'");
            }
        }

        if (stack.size() != 1) { // Final result should be the only item in the stack
            throw new IllegalArgumentException("Invalid expression: too many operands.");
        }

        return stack.pop();
    }

    // This Method checks if a string is a numeric operand
    private static boolean isOperand(String token) {
        try {
            Integer.parseInt(token);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // This Method checks if a string is a valid operator
    private static boolean isOperator(String token) {
        return token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/") || token.equals("%");
    }

    // This Method performs arithmetic operations
    private static int performOperation(String operator, int operand1, int operand2) {
        switch (operator) {
            case "+": return operand1 + operand2;
            case "-": return operand1 - operand2;
            case "*": return operand1 * operand2;
            case "/": 
                if (operand2 == 0) throw new ArithmeticException("Division by zero.");
                return operand1 / operand2;
            case "%": 
                if (operand2 == 0) throw new ArithmeticException("Division by zero.");
                return operand1 % operand2;
            default: throw new IllegalArgumentException("Invalid operator: " + operator);
        }
    }

    public static void main(String[] args) {
        // Test cases 
        String[] expressions = {
            "100 200 +",                     // 100 + 200 = 300
            "150 25 /",                      // 150 / 25 = 6
            "300 400 *",                     // 300 * 400 = 120000
            "500 100 200 + *",               // 500 * (100 + 200) = 150000
            "1000 300 %",                    // 1000 % 300 = 100
            "250 50 -",                      // 250 - 50 = 200
            "100 0 /",                       // Division by zero
            "700 +",                         // Invalid expression: insufficient operands
            "400 500 600 +",                 // Invalid expression: too many operands
            "300 400 &"                      // Invalid token: unrecognized operator
        };

        for (String expr : expressions) {
            try {
                int result = evaluatePostfix(expr);
                System.out.println("Expression: " + expr + " = " + result);
            } catch (Exception e) {
                System.out.println("Expression: " + expr + " Error: " + e.getMessage());
            }
        }
    }
}
