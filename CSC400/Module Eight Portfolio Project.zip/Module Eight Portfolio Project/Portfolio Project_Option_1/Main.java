import java.util.ArrayList;
import java.util.Scanner;

class Person {
    private String firstName;
    private String lastName;
    private int age;

    public Person(String firstName, String lastName, int age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return lastName + ", " + firstName + " - Age: " + age;
    }
}

class Queue {
    private ArrayList<Person> queue;

    public Queue() {
        this.queue = new ArrayList<>();
    }

    public void addPerson(Person person) {
        queue.add(person);
    }

    public void displayQueue() {
        for (Person person : queue) {
            System.out.println(person);
        }
    }

    public void sortByLastNameDescending() {
        quickSort(0, queue.size() - 1, "lastName");
    }

    public void sortByAgeDescending() {
        quickSort(0, queue.size() - 1, "age");
    }

    private void quickSort(int low, int high, String sortBy) {
        if (low < high) {
            int pivotIndex = partition(low, high, sortBy);
            quickSort(low, pivotIndex - 1, sortBy);
            quickSort(pivotIndex + 1, high, sortBy);
        }
    }

    private int partition(int low, int high, String sortBy) {
        Person pivot = queue.get(high);
        int i = low - 1;

        for (int j = low; j < high; j++) {
            boolean condition = false;
            if (sortBy.equals("lastName")) {
                condition = queue.get(j).getLastName().compareTo(pivot.getLastName()) > 0;
            } else if (sortBy.equals("age")) {
                condition = queue.get(j).getAge() > pivot.getAge();
            }

            if (condition) {
                i++;
                swap(i, j);
            }
        }
        swap(i + 1, high);
        return i + 1;
    }

    private void swap(int i, int j) {
        Person temp = queue.get(i);
        queue.set(i, queue.get(j));
        queue.set(j, temp);
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Queue queue = new Queue();

        for (int i = 0; i < 5; i++) {
            System.out.print("Enter details for person " + (i + 1) + " (First Name, Last Name, Age): ");
            String firstName = scanner.next();
            String lastName = scanner.next();
            int age = scanner.nextInt();
            queue.addPerson(new Person(firstName, lastName, age));
        }

        System.out.println("\nOriginal Queue:");
        queue.displayQueue();

        System.out.println("\nQueue Sorted by Last Name (Descending):");
        queue.sortByLastNameDescending();
        queue.displayQueue();

        System.out.println("\nQueue Sorted by Age (Descending):");
        queue.sortByAgeDescending();
        queue.displayQueue();

        scanner.close();
    }
}
