public static void main(String[] args) {
    // Create an instance of CustomLinkedList
    CustomLinkedList linkedList = new CustomLinkedList();

    // Test 1: Insert elements
    System.out.println("Inserting elements: 1, 2, 3");
    linkedList.insert(1);
    linkedList.insert(2);
    linkedList.insert(3);
    displayList(linkedList);

    // Test 2: Delete an existing element
    System.out.println("\nDeleting element 2...");
    boolean deleted = linkedList.delete(2);
    System.out.println("Element 2 deleted: " + deleted);
    displayList(linkedList);

    // Test 3: Attempt to delete a non-existent element
    System.out.println("\nAttempting to delete element 5...");
    deleted = linkedList.delete(5);
    System.out.println("Element 5 deleted: " + deleted);
    displayList(linkedList);

    // Test 4: Insert another element and display
    System.out.println("\nInserting element 4...");
    linkedList.insert(4);
    displayList(linkedList);

    // Test 5: Iterate through the list
    System.out.println("\nIterating through the linked list:");
    Iterator<Integer> iterator = linkedList.iterator();
    while (iterator.hasNext()) {
        System.out.print(iterator.next() + " ");
    }
    System.out.println();
}

// Helper method to display the list using the iterator
public static void displayList(CustomLinkedList linkedList) {
    System.out.print("Current List: ");
    Iterator<Integer> iterator = linkedList.iterator();
    while (iterator.hasNext()) {
        System.out.print(iterator.next() + " ");
    }
    System.out.println();
}
