import java.util.Arrays;

public class MergeSortExample {
    public static void main(String[] args) {
        Golfer[] golfers = {
            new Golfer("Jonathon", 10, "8:30 AM"),
            new Golfer("Troy", 5, "9:00 AM"),
            new Golfer("Jerome", 10, "8:45 AM"),
            new Golfer("Bill", 3, "8:15 AM")
        };
        
        mergeSort(golfers, 0, golfers.length - 1);
        
        System.out.println("Sorted Tee Times:");
        Arrays.stream(golfers).forEach(System.out::println);
    }

    static void mergeSort(Golfer[] arr, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;
            mergeSort(arr, left, mid);
            mergeSort(arr, mid + 1, right);
            merge(arr, left, mid, right);
        }
    }

    static void merge(Golfer[] arr, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        Golfer[] leftArray = new Golfer[n1];
        Golfer[] rightArray = new Golfer[n2];

        System.arraycopy(arr, left, leftArray, 0, n1);
        System.arraycopy(arr, mid + 1, rightArray, 0, n2);

        int i = 0, j = 0, k = left;

        while (i < n1 && j < n2) {
            if (leftArray[i].compareTo(rightArray[j]) <= 0) {
                arr[k++] = leftArray[i++];
            } else {
                arr[k++] = rightArray[j++];
            }
        }

        while (i < n1) {
            arr[k++] = leftArray[i++];
        }

        while (j < n2) {
            arr[k++] = rightArray[j++];
        }
    }
}

class Golfer implements Comparable<Golfer> {
    String name;
    int handicap;
    String time;

    Golfer(String name, int handicap, String time) {
        this.name = name;
        this.handicap = handicap;
        this.time = time;
    }

    @Override
    public int compareTo(Golfer other) {
        if (this.handicap != other.handicap) {
            return Integer.compare(this.handicap, other.handicap);
        }
        return this.time.compareTo(other.time);
    }

    @Override
    public String toString() {
        return name + " (Handicap: " + handicap + ", Tee Time: " + time + ")";
    }
}
