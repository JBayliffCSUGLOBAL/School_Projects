import java.util.HashMap;
import java.util.Map;

public class Bag<T> {
    // HashMap to store elements and their counts
    private Map<T, Integer> bag;

    // Constructor to initialize the bag
    public Bag() {
        bag = new HashMap<>();
    }

    // Method to add an item to the bag
    public void add(T item) {
        // If the item already exists, increment its count
        bag.put(item, bag.getOrDefault(item, 0) + 1);
    }

    // Method to remove one occurrence of the item from the bag
    public void remove(T item) {
        if (bag.containsKey(item)) {
            // If the count of the item is greater than 1, decrement the count
            if (bag.get(item) > 1) {
                bag.put(item, bag.get(item) - 1);
            } else {
                // Otherwise, remove the item from the bag
                bag.remove(item);
            }
        }
    }

    // Method to check if the bag contains a specific item
    public boolean contains(T item) {
        return bag.containsKey(item);
    }

    // Method to count the occurrences of an item in the bag
    public int count(T item) {
        return bag.getOrDefault(item, 0);
    }

    // Method to print the contents of the bag
    public void printBagContents() {
        for (Map.Entry<T, Integer> entry : bag.entrySet()) {
            System.out.println(entry.getKey() + " occurs " + entry.getValue() + " times.");
        }
    }

    // Main method to demonstrate usage of the Bag class
    public static void main(String[] args) {
        // Create an instance of the Bag class
        Bag<String> myBag = new Bag<>();

        // Add several elements to the bag, including duplicates
        myBag.add("Apple");
        myBag.add("Banana");
        myBag.add("Apple");
        myBag.add("Orange");
        myBag.add("Banana");
        myBag.add("Apple");

        // Print the bag contents
        System.out.println("Bag contents after adding elements:");
        myBag.printBagContents();

        // Test the contains method for a few elements
        System.out.println("\nDoes the bag contain 'Apple'? " + myBag.contains("Apple"));
        System.out.println("Does the bag contain 'Grape'? " + myBag.contains("Grape"));

        // Test the count method for a few elements
        System.out.println("\nCount of 'Apple' in the bag: " + myBag.count("Apple"));
        System.out.println("Count of 'Banana' in the bag: " + myBag.count("Banana"));

        // Remove an element from the bag
        myBag.remove("Banana");

        // Print the bag contents again
        System.out.println("\nBag contents after removing 'Banana':");
        myBag.printBagContents();

        // Test the contains method for the removed element
        System.out.println("\nDoes the bag contain 'Banana' after removal? " + myBag.contains("Banana"));

        // Test the count method for the removed element
        System.out.println("Count of 'Banana' in the bag after removal: " + myBag.count("Banana"));
    }
}
