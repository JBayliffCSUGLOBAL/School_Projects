public class BagDemo {
    public static void main(String[] args) {
        // Create two instances of the Bag class
        Bag<String> bag1 = new Bag<>();
        Bag<String> bag2 = new Bag<>();

        // Add elements to the first bag, including duplicates
        bag1.add("Apple");
        bag1.add("Banana");
        bag1.add("Apple");
        bag1.add("Orange");

        // Add elements to the second bag, including duplicates
        bag2.add("Banana");
        bag2.add("Grapes");
        bag2.add("Apple");
        bag2.add("Pineapple");

        // Print the size of each bag using the size method
        System.out.println("Size of bag1: " + bag1.size());  // Output: 4
        System.out.println("Size of bag2: " + bag2.size());  // Output: 4

        // Merge the two bags together using the merge method
        bag1.merge(bag2);

        // Print the merged bag contents
        System.out.print("Merged bag contents: ");
        bag1.printBag();  // Output: [Apple, Banana, Apple, Orange, Banana, Grapes, Apple, Pineapple]

        // Create a new bag containing only the distinct elements using the distinct method
        Bag<String> distinctBag = bag1.distinct();

        // Print the distinct bag contents
        System.out.print("Distinct bag contents: ");
        distinctBag.printBag();  // Output: [Apple, Banana, Orange, Grapes, Pineapple]
    }
}
